export default {
  clicks_one: '{{count}} click',
  clicks_other: '{{count}} clicks',
  reset: 'Reset',
};